# Dominant color async

Get the dominant color of an image, asynchronously

⚠️ **Work in progress! Please don't use it yet**
